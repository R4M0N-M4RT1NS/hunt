# hunt
A project to test my skills
A bot that will detect when a new user joins the server and create a fixed profile based on their ID. 
It will implement a "reputation" system to categorize users based on activity and good behavior. In the final stage, it will generate a ranking system that influences which roles users will receive.
